const express = require("express");
const app = express();
const http = require("http");
const server = http.createServer(app);
const routes = require("./routes/index");
const bodyParser = require("body-parser");
const cors = require("cors");
require("./config/database").connect();
require("dotenv").config();
const multer = require("multer");
const path = require("path");
const socketIO = require('socket.io');
const io = socketIO(server, {
  cors: {
    origin: '*',
  },
});
const Message = require('./models/message'); // Import the message model
const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "images");
  },
  filename: (req, file, cb) => {
    let extArray = file.mimetype.split("/");
    let extension = extArray[extArray.length - 1];
    cb(null, new Date().toISOString().replace(/:/g, "-") + "-." + extension);
  },
});
app.use(bodyParser.json());
app.use(express.json({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});
app.use(multer({ storage: fileStorage }).single("file"));
app.use("/images", express.static(path.join(__dirname, "images")));
app.use(bodyParser.json());
app.use(express.json({ extended: true }));

app.use("/api", routes);

app.get("/api", (req, res) => {
  res.json({ message: "Welcome to Scholarship Project" });
});
app.post("/api/image/upload", (req, res) => {
  if (req.file) {
    res.json({ status: "success", data: req.file.path });
  } else {
    res.status(400).json({ status: "failed", data: "Failed to upload" });
  }
});


// const users = [];

// io.on('connection', (socket) => {

//   socket.on('join', ({ username }, callback) => {
//     const existingUser = users.find(user => user.username === username);
//     if (existingUser && !existingUser.isTemporarilyDisconnected) {
//       return callback('Username is taken. Please choose another.');
//     }

//     socket.join('chat');

//     users.push(username);
//     io.to('chat').emit('userList', users);

//     socket.emit('message', { user: '', text: `Welcome, ${username}!` });
//     socket.broadcast.to('chat').emit('message', { user: '', text: `${username} has joined the chat.` });
//     Message.find().sort({ timestamp: -1 }).populate("userId").limit(50)  // Retrieve the last 50 messages
//       .then(messages => {
//         socket.emit('previousMessages', messages);  // Send previous messages to the new user
//         callback();
//       })
//       .catch(err => {
//         console.error('Error retrieving messages', err);
//         callback('Failed to retrieve messages');
//       });

//     callback();
//   });

//   // socket.on('sendMessage', ({ user, text }, callback) => {
//   //   io.to('chat').emit('message', { user, text });
//   //   callback();
//   // });
//   socket.on('sendMessage', ({ user, userId, text, url = "" }, callback) => {
//     let message = new Message({ user, userId, text, url });
//     message.save()  // Save the message to MongoDB
//       .then(() => {
//         Message.findById(message._id).populate("userId").then(msg => {
//           io.to('chat').emit('message', msg);  // Emit the message to all clients
//           callback();
//         })
//       })
//       .catch(err => {
//         console.error('Error saving message to database', err);
//         callback('Failed to save message');
//       });
//   });
//   socket.on('editMessage', ({ user, userId, text, url = "", id }, callback) => {
//     Message.findByIdAndUpdate(id, {
//       user: user,
//       text: text,
//       userId: userId,
//       url: url
//     })  // edit the message to MongoDB
//       .then(() => {
//         // Message.findById(id).populate("userId").then(msg => {
//         //   console.log("Edit: ", id);
//         //   io.to('chat').emit('message', {
//         //     edit: true,
//         //     _id: msg._id,
//         //     user: msg.user,
//         //     text: msg.text,
//         //     userId: msg.userId,
//         //     url: msg.url
//         //   });  // Emit the message to all clients
//         //   callback();
//         // })
//         Message.find().sort({ timestamp: -1 }).populate("userId").limit(50)  // Retrieve the last 50 messages
//           .then(messages => {
//             socket.emit('previousMessages', messages);  // Send previous messages to the new user
//             callback();
//           })
//           .catch(err => {
//             console.error('Error retrieving messages', err);
//             callback('Failed to retrieve messages');
//           });
//       })
//       .catch(err => {
//         console.error('Error edit message to database', err);
//         callback('Failed to edit message');
//       });

//   });
//   socket.on('deleteMessage', ({ id }, callback) => {

//     Message.findByIdAndDelete(id)  // delete the message to MongoDB
//       .then(() => {
//         io.to('chat').emit('message', { delete: true, deleteId: id });  // Emit the message to all clients
//         callback();
//       })
//       .catch(err => {
//         console.error('Error deleting message to database', err);
//         callback('Failed to delete message');
//       });

//   });
//   // socket.on('disconnect', () => {
//   //   console.log('User disconnected');

//   //   const index = users.indexOf(socket.username);

//   //   if (index !== -1) {
//   //     users.splice(index, 1);
//   //   }

//   //   io.to('chat').emit('userList', users);
//   //   io.to('chat').emit('message', { user: 'Admin', text: `${socket.username} has left the chat.` });
//   // });
//   socket.on('disconnect', () => {
//     const user = users.find((u) => u.socketId === socket.id);
//     if (user) {
//       user.isTemporarilyDisconnected = true;
//       setTimeout(() => {
//         user.isTemporarilyDisconnected = false;
//         users.splice(users.indexOf(user), 1);
//         io.to('chat').emit('userList', users);

//       }, 5000); // allows 5 seconds for reconnection
//     }
//   });

// });


let users = [];
const addUser = (userId, socketId) => {
  !users.some((user) => user.userId === userId) &&
    users.push({ userId, socketId });
};

const removeUser = (socketId) => {
  users = users.filter((user) => user.socketId !== socketId);
};

const getUser = (userId) => {
  return users.find((user) => user.userId === userId);
};

io.on("connection", (socket) => {
  socket.on("addUser", (userId) => {
    addUser(userId, socket.id);
    io.emit("getUsers", users);
  });
  socket.on("sendMessage", ({ senderId, recieverId, text }) => {
    console.log("New: ",{ senderId, recieverId, text });
    const user = getUser(recieverId);
    user &&
      io.to(user.socketId).emit("getMessage", {
        senderId,
        text,
        recieverId,
      });
  });
  socket.on("disconnect", () => {
    console.log("a user disconnected!");
    removeUser(socket.id);
    console.log("Diconnected Users: ", users);
    io.emit("getUsers", users);
  });
});
const port = process.env.PORT || 5000;
server.listen(port, () => {
  console.log(`Now listening on port ${port}`);
});
