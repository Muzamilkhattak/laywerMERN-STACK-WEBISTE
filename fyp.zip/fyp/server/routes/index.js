const express = require("express");
const router = express();
const userRoutes = require("./user.routes");
const adminRoutes = require("./admin.routes");
const lawyerRoutes = require("./lawyer.routes");
const chatRoute = require("./chat.routes");

router.use("/admin", adminRoutes);
router.use("/user", userRoutes);
router.use("/chat", chatRoute);
router.use("/lawyer", lawyerRoutes);
module.exports = router;
