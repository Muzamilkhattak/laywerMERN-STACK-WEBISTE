const express = require("express");
const { check } = require("express-validator");
const router = express.Router();
const controller = require("../controllers/user.controller");

router.post(
  "/login",
  [
    check("email", "email is required").not().isEmpty(),
    check("password", "password is required").not().isEmpty(),
  ],
  controller.login
);
router.post(
  "/register",
  [
    check("name", "name is required").not().isEmpty(),
    check("state", "state is required").not().isEmpty(),
    check("city", "city is required").not().isEmpty(),
    check("email", "email is required").trim().not().isEmpty(),
    check("phoneNumber", "phoneNumber is required").not().isEmpty(),
    check("password", "password is required").not().isEmpty(),
  ],
  controller.register
);
router.get("/", controller.getUsers);

module.exports = router;
