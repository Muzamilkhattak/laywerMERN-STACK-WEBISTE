const express = require('express');
const { check } = require('express-validator');
const router = express.Router();
const chatController = require('../controllers/chat.controller');
const auth = require('../middlewares/auth');

router.post(
  '/get',
  [auth],
  [check('senderId').not().isEmpty(), check('recieverId').not().isEmpty()],
  chatController.getMessages
);

router.get('/chatlist', [auth], chatController.getChatlist);

router.post(
  '/add',
  [auth],
  [
    check('senderId').not().isEmpty(),
    check('recieverId').not().isEmpty(),
    check('text').not().isEmpty(),
  ],
  chatController.sendMessage
);
router.post(
  '/status',
  [auth],
  [check('recieverId').not().isEmpty(), check('status').isBoolean()],
  chatController.changeReadStatus
);

router.post(
  '/chatlist/add',
  [auth],
  [check('senderId').not().isEmpty(), check('recieverId').not().isEmpty()],
  chatController.addChatList
);

module.exports = router;
