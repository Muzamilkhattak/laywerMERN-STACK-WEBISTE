const mongoose = require("mongoose");
const LOCAL_URL = "mongodb://127.0.0.1:27017/lawyer";
exports.connect = () => {
  mongoose
    .connect(LOCAL_URL)
    .then(() => {
      console.log("Successfully connected to database");
    })
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
};
