const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema({
  email: { type: String, required: true },
  password: { type: String },
  playerId: { type: String, default: "" },
});

module.exports = mongoose.model("Admin", adminSchema);
