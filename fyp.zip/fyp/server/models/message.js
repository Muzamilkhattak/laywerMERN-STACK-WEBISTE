const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  user: String,
  text: String,
  url: { type: String, default: "" },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  wakeelId: { type: mongoose.Schema.Types.ObjectId, ref: "Lawyer" },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

const Message = mongoose.model('MessageModel', messageSchema);

module.exports = Message;