const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, default: "" },
    email: { type: String, required: true },
    phoneNumber: { type: String, default: "" },
    state: { type: String, default: "" },
    city: { type: String, default: "" },
    password: { type: String, required: true },
    isDeleted: { type: Boolean, default: false },
    status: { type: Boolean, default: true },
  },
  {
    timestamps: true,
    autoIndex: true,
  }
);

module.exports = mongoose.model("User", userSchema);
