const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    name: { type: String, default: "" },
    email: { type: String, required: true },
    phoneNumber: { type: String, default: "" },
    state: { type: String, default: "" },
    city: { type: String, default: "" },
    cnic: { type: String, default: "" },
    experience: { type: String, default: "" },
    experienceInYears: { type: String, default: "" },
    qualifications: { type: String, default: "" },
    areaOfExpertise: { type: String, default: "" },
    skypeId: { type: String, default: "" },
    profileImageUrl: { type: String, default: "" },
    resumeUrl: { type: String, default: "" },
    password: { type: String, required: true },
    isDeleted: { type: Boolean, default: false },
    status: { type: Boolean, default: false },
  },
  {
    timestamps: true,
    autoIndex: true,
  }
);

module.exports = mongoose.model("Lawyer", schema);
