const mongoose = require("mongoose");

const chatlistSchema = new mongoose.Schema(
  {
    users: [
      {
        userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        lastMessage: { type: String },
        isReadBy: { type: Boolean, default: false },
        timestamps: { type: Date, default: new Date() },
      },
    ],
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

chatlistSchema.virtual("client", {
  ref: "User", // Your MonthlyMenu model name
  localField: "users.userId", // Your local field, like a `FOREIGN KEY` in RDS
  foreignField: "_id", // Your foreign field which `localField` links to. Like `REFERENCES` in RDS
});

chatlistSchema.virtual("lawyer", {
  ref: "Lawyer", // Your MonthlyMenu model name
  localField: "users.userId", // Your local field, like a `FOREIGN KEY` in RDS
  foreignField: "_id", // Your foreign field which `localField` links to. Like `REFERENCES` in RDS
});

module.exports = mongoose.model("Chatlist", chatlistSchema);
