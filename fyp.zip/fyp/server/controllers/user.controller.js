const User = require("../models/user");
const { validationResult } = require("express-validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    let users = await User.find({ isDeleted: false })
      .select("-password")
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    if (!users) {
      return res.status(400).json({ errors: [{ msg: "No users" }] });
    }
    const total = await User.find({ isDeleted: false }).countDocuments();

    res.json({
      msg: "success",
      data: users,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    res.status(500).json({ msg: "failed", errors: error });
  }
};
const register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const {
      name,
      state,
      city,
      email,
      phoneNumber,
      password,
    } = req.body;
    const result = await User.findOne({ email, isDeleted: false });
    if (result) {
      return res
        .status(400)
        .json({ errors: [{ msg: "This email is already registered." }] });
    }

    let user = new User({
      name,
      state,
      city,
      email,
      phoneNumber,
      password
    });
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);
    const createdUser = await user.save();
    const payload = {
      user: {
        id: createdUser._id,
      },
    };
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      (err, token) => {
        if (err) throw err;
        res.json({ token, user });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "failed", errors: [{ msg: error.message }] });
  }
};
const login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  const { email, password } = req.body;
  try {
    let user = await User.findOne({ email, isDeleted: false });
    if (!user) {
      return res
        .status(400)
        .json({ errors: [{ msg: "invalid credentials" }] });
    }
    if (!user.status) {
      return res
        .status(400)
        .json({ errors: [{ msg: "user is blocked from admin" }] });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ errors: [{ msg: "invalid credentials" }] });
    }
    if (user.isDeleted) {
      return res.status(400).json({ errors: [{ msg: "User is deleted" }] });
    }

    const payload = {
      user: {
        id: user._id,
      },
    };
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      (err, token) => {
        if (err) throw err;
        res.json({ token, user });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(500).json({ errors: error });
  }
};

module.exports = {
  getUsers,
  register,
  login
};
