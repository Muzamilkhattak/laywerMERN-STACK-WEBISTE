const Message = require('../models/Message1');
const Chatlist = require('../models/Chatlist');
const { validationResult } = require('express-validator');

const getMessages = async (req, res) => {
  const { senderId, recieverId } = req.body;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    let messages = await Message.find({
      $or: [
        { senderId, recieverId },
        { senderId: recieverId, recieverId: senderId },
      ],
    });

    messages = messages.sort(function (x, y) {
      return x.createdAt - y.createdAt;
    });
    res.json({ msg: 'success', data: messages });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getChatlist = async (req, res) => {
  try {
    let chatlist = await Chatlist.find({
      userId: req.user.id,
    })
      .populate('client')
      .populate('lawyer')
      .exec();

    if (chatlist.length <= 0) {
      let newchatlist = new Chatlist({
        userId: req.user.id,
      });

      newchatlist = await newchatlist.save();
      return res.json({ msg: 'success', data: newchatlist });
    }

    let users = [...chatlist[0].users];
    users = users.sort(function (x, y) {
      return y.timestamps - x.timestamps;
    });
    const uCopy = [...chatlist[0].client, ...chatlist[0].lawyer];
    chatlist[0].users = users;
    res.json({ msg: 'success', data: { list: chatlist[0], users: uCopy } });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const sendMessage = async (req, res) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { senderId, recieverId, text } = req.body;

  console.log(senderId, recieverId, text);
  const date = new Date();

  let userChatList = await Chatlist.find({ userId: senderId });
  let recieverChatList = await Chatlist.find({ userId: recieverId });

  if (userChatList.length > 0) {
    const users = [...userChatList[0].users];
    const index = users.findIndex((us) => us.userId == recieverId);

    if (index >= 0) {
      users[index].lastMessage = text;
      users[index].isReadBy = true;
      users[index].timestamps = date;
    } else {
      users.push({
        userId: recieverId,
        isReadBy: true,
        lastMessage: text,
      });
    }

    await Chatlist.findOneAndUpdate(
      { userId: senderId },
      { $set: { users: users } }
    );
  } else {
    userChatList = new Chatlist({
      userId: senderId,
      users: [
        {
          userId: recieverId,
          isReadBy: true,
          lastMessage: text,
        },
      ],
    });
    await userChatList.save();
  }

  if (recieverChatList.length > 0) {
    const users = [...recieverChatList[0].users];
    const index = users.findIndex((us) => us.userId == senderId);

    if (index >= 0) {
      users[index].lastMessage = text;
      users[index].isReadBy = false;
      users[index].timestamps = date;
    } else {
      users.push({
        userId: senderId,
        isReadBy: false,
        lastMessage: text,
        timestamps: date,
      });
    }

    await Chatlist.findOneAndUpdate(
      { userId: recieverId },
      { $set: { users: users } }
    );
  } else {
    recieverChatList = new Chatlist({
      userId: recieverId,
      users: [
        {
          userId: senderId,
          isReadBy: false,
          lastMessage: text,
          timestamps: date,
        },
      ],
    });
    await recieverChatList.save();
  }

  const message = new Message({
    senderId,
    recieverId,
    text,
  });

  await message.save();

  res.json({ msg: 'success', data: message });
};

const addChatList = async (req, res) => {
  try {
    const { recieverId, senderId } = req.body;
    let userChatList = await Chatlist.findOne({ userId: senderId });
    if (userChatList) {
      return res.json({ msg: 'success', data: userChatList });
    }
    const chatList = new Chatlist({
      userId: senderId,
      users: [
        {
          userId: recieverId,
          isReadBy: true,
          lastMessage: 'Hey! welcome to the chat.',
        },
      ],
    });
    const newchatlist = await chatList.save();
    res.json({ msg: 'success', data: newchatlist });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const changeReadStatus = async (req, res) => {
  try {
    const recieverId = req.body.recieverId;
    const status = req.body.status;
    let chatlist = await Chatlist.find({
      userId: req.user.id,
    });

    if (chatlist.length <= 0)
      return res.status(400).json({ message: 'No chatlist' });

    const userChatList = chatlist[0];
    const users = [...userChatList.users];
    const index = users.findIndex((us) => us.userId == recieverId);

    if (index >= 0) {
      users[index].isReadBy = status;
      await Chatlist.findOneAndUpdate(
        { userId: req.user.id },
        { $set: { users: users } }
      );
    }
    chatlist[0].users = users;
    res.json({ msg: 'success', data: chatlist[0] });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  sendMessage,
  getMessages,
  getChatlist,
  changeReadStatus,
  addChatList,
};
