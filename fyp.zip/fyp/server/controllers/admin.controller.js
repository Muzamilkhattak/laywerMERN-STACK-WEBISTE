const Admin = require("../models/admin");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");

const login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  const { email, password } = req.body;
  try {
    let user = await Admin.findOne({ email });
    if (!user) {
      if (email === "admin@admin.com") {
        user = new Admin({
          email,
          password,
        });
        await user.save();
        const payload = {
          user: {
            id: user._id,
            isAdmin: true,
          },
        };
        jwt.sign(
          payload,
          process.env.JWT_SECRET,
          (err, token) => {
            if (err) throw err;
            res.json({ token, user });
          }
        );
      } else {
        return res
          .status(400)
          .json({ errors: [{ msg: "Invalid credentials " }] });
      }
    }

    if (user.password !== password) {
      return res.status(400).json({ errors: [{ msg: "Invalid credentials" }] });
    }
    const payload = {
      user: {
        id: user._id,
        isAdmin: true,
      },
    };
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      (err, token) => {
        if (err) throw err;
        res.json({ token, user });
      }
    );
  } catch (error) {
    console.log(error);
    res.status(500).json({ errors: error });
  }
};

module.exports = {
  login
};
