import React, { useEffect, useState } from 'react'
import './App.css'

// bootstrap link
import 'bootstrap/dist/css/bootstrap.min.css';

// Rounting 
import { Route, Routes, BrowserRouter, Navigate } from 'react-router-dom';
import Login from './Components/Login/Login';
import Landingpage from './Components/Landingpage/Landingpage';
import Register from './Components/Register/Register';
import Contact from './Components/Contactus/Contact';
import Media from './Components/Media/Media';
import About from './Components/Aboutus/About';
import Blog from './Components/Blog/Blog';
import Startabusiness from './Components/StartaBusiness/Startabusiness';
import LandingPage2 from './Components/LandingPage2/LandingPage2';
import Lawyer from './Components/Lawyerprofile/Lawyer';
import { Login as AdminLogin } from './Admin/Login/index';
import { Dashboard as AdminDashboard } from './Admin/Dashboard';
import { Lawyers } from './Admin/Lawyers';
import { Sidebar } from './Admin/Sidebar';
import WakeeRegister from './Wakeel/Register/Wakeelr';
import WakeeLogin from './Wakeel/Login/Login';
import { WakeelSidebar } from './Wakeel/Sidebar';
import { WakeelProfile } from './Wakeel/Profile';
import { Messages } from './Wakeel/Messages';


export default function App() {
  const [url, setUrl] = useState("/");

  useEffect(() => {
    const currentUrl = window.location.pathname;
    setUrl(currentUrl);
  }, []);

  const renderRoutes = () => {
    if (url === "/") {
      return (
        <Routes>
          <Route path='/' element={<Landingpage />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/media' element={<Media />} />
          <Route path='/about' element={<About />} />
          <Route path='/blog' element={<Blog />} />
          <Route path='/startabusiness' element={<Startabusiness />} />
          <Route path='/landingpage2' element={<LandingPage2 />} />
          <Route path='/lawyer' element={<Lawyer />} />
        </Routes>
      )
    } else if (url === "/admin") {
      return !sessionStorage.getItem("lawyer-admin") ? (
        <Routes>
          <Route path='/admin' element={<AdminLogin />} />
        </Routes>
      ) : (
        <Sidebar>
          <Routes>
            <Route path="/admin" element={<Navigate to={"/admin/dashboard"} />} />
            <Route path='/admin/dashboard' element={<AdminDashboard />} />
            <Route path='/admin/lawyers' element={<Lawyers />} />
          </Routes>
        </Sidebar>
      )
    } else if (url === "/wakeel") {
      return !sessionStorage.getItem("lawyer-wakeel") ? (
        <Routes>
          <Route path='/wakeel' element={<WakeeLogin />} />
          <Route path='/wakeel/register' element={<WakeeRegister />} />
        </Routes>
      ) : (
        <WakeelSidebar>
          <Routes>
            <Route path="/wakeel" element={<Navigate to={"/wakeel/profile"} />} />
            <Route path='/wakeel/profile' element={<WakeelProfile />} />
            <Route path='/wakeel/chat' element={<Messages />} />
          </Routes>
        </WakeelSidebar>
      )
    }
  };

  return <BrowserRouter>{renderRoutes()}</BrowserRouter>;
}
