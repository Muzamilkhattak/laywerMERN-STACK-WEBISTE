import { Container, Table } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  approveLawyer,
  getLawyers,
} from "../../APIS";
import { FcNext, FcPrevious } from "react-icons/fc";

const LIMIT = 10;
export const Lawyers = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [vendors, setVendors] = useState([]);

  useEffect(() => {
    getLawyers(currentPage, LIMIT).then(res => {
      setVendors(res.data.data);
      setTotalPages(res.data.totalPages);
      setLoading(false);
    })
      .catch(err => {
        alert(err.message)
      })
  }, [currentPage]);


  const approveChangeHandler = async (e, id) => {
    const c = window.confirm(
      `Are you sure you want to ${e.target.checked ? "Approve" : "Un-Approve"}?`
    );
    if (!c) return;

    try {
      const payload = {
        id: id,
        status: e.target.checked,
      };
      setLoading(true);
      await approveLawyer(payload);
      getLawyers(1, LIMIT).then(res => {
        setVendors(res.data.data);
        setTotalPages(res.data.totalPages);
        setLoading(false);
      })
        .catch(err => {
          alert(err.message)
        })
      setLoading(false);
      toast.success("Approved successfully!");

    } catch (error) {
      toast.error(error.message);
    }
  };
  if (loading) return <></>;
  return (
    <Container >
      <h3 className="mb-4">Lawyers</h3>
      <Table className="table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Image</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>State</th>
            <th>City</th>
            <th>qualifications</th>
            <th>experience</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {vendors.map((item, index) => (
            <tr>
              <td>{index + 1}</td>
              <td>
                <img
                  width={50}
                  height={50}
                  style={{ borderRadius: "50%" }}
                  src={
                    item.profileImageUrl && item.profileImageUrl.length
                      ? "http://localhost:5000/" + item.profileImageUrl
                      : "placeholder.png"
                  }
                  alt={item.name}
                />
              </td>
              <td>{item.name}</td>
              <td>{item.email}</td>
              <td>{item.phoneNumber}</td>
              <td>{item.state}</td>
              <td>{item.city}</td>
              <td>{item.qualifications}</td>
              <td>{item.experience}</td>
              <td>
                <div className="form-check form-switch" style={{display: 'flex', alignItems: 'center', gap: '5px'}}>
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="customerStatus"
                    onChange={(e) => approveChangeHandler(e, item._id)}
                    checked={item.status}
                  />
                  <label className="form-check-label" htmlFor="customerStatus">
                    Dis-Approve/Approved
                  </label>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Container
        className="pagination-container"
        style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          maxWidth: "150px",
          margin: 0,
        }}
      >
        <Button
          className="btn primary-button"
          disabled={currentPage === 1}
          style={{ display: "flex", alignItems: "center", gap: "5px" }}
          onClick={() => {
            setCurrentPage((p) => p - 1);
            setTimeout(() => {

            }, 100);
          }}
        >
          <FcPrevious />

          <>Previous</>
        </Button>
        <Container
          style={{ display: "flex", alignItems: "center", gap: "5px" }}
        >
          <span> {currentPage}</span> <span>/</span>
          <span> {totalPages}</span>
        </Container>
        <Button
          className="btn primary-button px-2"
          onClick={() => {
            setCurrentPage((p) => p + 1);
            setTimeout(() => {

            }, 100);
          }}
          disabled={totalPages <= currentPage}
          style={{ display: "flex", alignItems: "center", gap: "5px" }}
        >
          <>Next</>
          <FcNext />
        </Button>
      </Container>
    </Container>
  );
};
