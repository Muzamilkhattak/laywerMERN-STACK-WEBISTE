import { useState } from "react";
import { Form, Formik } from "formik";
import * as yup from "yup";
import { Input } from "./input";
import { toast } from "react-toastify";
import { Button, Card, Container } from "react-bootstrap";
import Spinner from "react-bootstrap/Spinner";
import { loginAdmin } from "../../APIS";

export const Login = () => {
	const [loading, setLoading] = useState(false);
	const [state] = useState({
		email: "",
		password: "",
	});

	const validations = yup.object().shape({
		email: yup.string().email().required(),
		password: yup.string().min(6).required(),
	});

	const handleSubmit = async (values) => {
		try {
			setLoading(true);
			const res = await loginAdmin(values);
			if (res.status === 200) {
				sessionStorage.setItem("lawyer-admin", res.data.token);
				window.location.reload();
				toast.success("Login successfully!");
			}
			setLoading(false);
		} catch (error) {
			setLoading(false);
			toast.error(error?.response?.data?.errors[0]?.msg);
		}
	};

	if (sessionStorage.getItem('lawyer-admin')) {
		
	}

	return (
		<Container className="login-container">
			<Card>
				<Card.Body>
					<Formik
						initialValues={state}
						validationSchema={validations}
						onSubmit={handleSubmit}
					>
						{() => (
							<>
								<Form className="p-5">
									<h3 className="mb-4">Admin Login</h3>
									<Input
										name="email"
										type="email"
										label="Email"
										placeholder="Enter your email"
									/>
									<Input
										label="Password"
										name="password"
										placeholder="Enter password"
										type="password"
									/>
									<Button type="submit" className="btn primary-button mt-3 px-5">
										{loading ? <Spinner animation="grow" /> : "Login"}
									</Button>
								</Form>
							</>
						)}
					</Formik>
				</Card.Body>
			</Card>
		</Container>
	);
};
