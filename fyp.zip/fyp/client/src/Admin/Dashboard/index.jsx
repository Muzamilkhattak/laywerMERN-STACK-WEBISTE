import { Col, Container, Row } from "react-bootstrap";
import { Card } from "./card";
import { HiOutlineUsers } from "react-icons/hi";
import { Sidebar } from "../Sidebar";

export const Dashboard = () => {

  return (
    <Container>
      <h3 className="mb-3">Dashboard</h3>
      <Row>
        <Col>
          <Card
            title="Customers"
            value={0}
            Icon={HiOutlineUsers}
            bgcolor="bg-green"
            txtcolor="text-green"
            borderColor="border-green"
          />
        </Col>
        <Col>
          <Card
            title="Lawyers"
            value={0}
            Icon={HiOutlineUsers}
            bgcolor="bg-blue"
            txtcolor="text-blue"
            borderColor="border-blue"
          />
        </Col>
      </Row>
    </Container>
  );
};
