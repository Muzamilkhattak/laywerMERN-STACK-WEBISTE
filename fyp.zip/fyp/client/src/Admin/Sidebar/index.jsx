import { useState } from "react";
import { Link } from "react-router-dom";
import { AiFillDashboard } from "react-icons/ai";
import { PiUsersFourFill } from "react-icons/pi";
import { FiLogOut } from "react-icons/fi";
import "./style.css";

export const Sidebar = ({ children }) => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const isAuth = sessionStorage.getItem("lawyer-admin");

  const logoutHandler = () => {
    const c = window.confirm("Are you sure to logout?");
    if (c) {
      sessionStorage.removeItem("lawyer-admin");
      window.location.replace("/admin");
    }
  };



  return (
    <div className={`sidebar-container`}>
      {isAuth && (
        <aside className="sidebar-wrapper">
          <div className="sidebar-brand">
            <h4 className="mt-4">Lawyer Admin</h4>
          </div>
          <ul className="sidebar-nav">
            <li
              className={
                activeTab.includes("dashboard") ? "active" : ""}
              onClick={() => setActiveTab("/admin/dashboard")}
            >
              <Link to="/admin/dashboard">
                <AiFillDashboard />
                <span>Dashboard</span>
              </Link>
            </li>

            <li
              className={
                activeTab.includes("lawyers") ? "active" : ""}
              onClick={() => setActiveTab("/admin/lawyers")}
            >
              <Link to="/admin/lawyers">
                <PiUsersFourFill />
                <span>Lawyers</span>
              </Link>
            </li>
            <li
              className={activeTab.includes("logout") ? "active" : ""}
              onClick={logoutHandler}
            >
              <a href="#logout">
                <FiLogOut />
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </aside>
      )}
      <section className="content-wrapper">{children}</section>
    </div>

  );
};
