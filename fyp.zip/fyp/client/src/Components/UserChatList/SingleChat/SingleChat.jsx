import chatIcon from "./assets/chatIcon.png";
import online from "./assets/online.png";
import { useEffect, useRef, useState } from "react";
import "./SingleChat.css";
import { SERVER_URL1 } from "../../../APIS";

const SingleChat = ({
  messages,
  sendMessageHandler,
  selectedUser,
}) => {
  const [message, setMessage] = useState("");
  let user = sessionStorage.getItem("lawyer-user") ? JSON.parse(sessionStorage.getItem("lawyer-user")) : null;
  const scrollRef = useRef();

  const getTime = (d) => {
    const date = new Date(d);
    return date.toLocaleTimeString();
  };

  const messageHandler = () => {
    sendMessageHandler(message);
    setMessage("");
  };
  const _handleKeyDown = (e) => {
    if (e.key === "Enter") {
      sendMessageHandler(message);
      setMessage("");
    }
  };

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <>
      <div className="chatMain userChat">
        <div className="chatMainHeader">
          <div className="chatMainHeaderCard">
            <div className="chatMainHeaderCardImg">
              <span className="onlineIcon">
                <img src={online} alt="" />
              </span>
              <div className="chatIcon">
                <img
                  src={
                    selectedUser?.profileImageUrl
                      ? SERVER_URL1  + selectedUser?.profileImageUrl
                      : "/placeholder.png"
                  }
                  alt=""
                />
              </div>
            </div>
            <div className="chatMainHeaderCardContent">
              <h6>{selectedUser?.name}</h6>
              <small className="chatActive">Active</small>
            </div>
          </div>
        </div>

        <div className="chatBox">
          {messages.map((message) =>
            user?.user._id.includes(message.recieverId) ? (
              <div className="reciever" ref={scrollRef} key={message._id}>
                {(
                  <>
                    <div className="recieverImg">
                      <img src={chatIcon} alt="" />
                    </div>
                    <div className="recieverMessage">
                      <p>{message.text}</p>
                      <small>{getTime(message.createdAt)}</small>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="sender" ref={scrollRef} key={message._id}>
                {(
                  <>
                    <div className="senderMessage">
                      <p>{message.text}</p>
                      <small>{getTime(message.createdAt)}</small>
                    </div>
                    <div className="senderImg">
                      <img src={chatIcon} alt="" />
                    </div>
                  </>
                )}
              </div>
            )
          )}
        </div>
        <div className="messageInputs">
          <div className="messageInput">
            <input
              type="text"
              className="form-control p-3"
              placeholder="Enter message there..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={_handleKeyDown}
            />
          </div>
          <button
            onClick={messageHandler}
            className="btn btn-primary p-3"
            disabled={!message.length}
          >
            Send
          </button>
        </div>
      </div>
    </>
  );
};

export default SingleChat;
