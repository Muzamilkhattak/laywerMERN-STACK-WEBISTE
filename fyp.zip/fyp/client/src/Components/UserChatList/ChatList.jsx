import { useEffect, useRef, useState } from "react";
import { getChatMessages, getChatlist, sendMessage } from "../../APIS";
import { toast } from "react-toastify";
import SingleChat from "./SingleChat/SingleChat";
import { io } from "socket.io-client";
import "./ChatList.css";

const ChatList = ({ chatingUser }) => {
  let user = sessionStorage.getItem("lawyer-user") ? JSON.parse(sessionStorage.getItem("lawyer-user")) : null;
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const socket = useRef();
  const [arrivalMessage, setArrivalMessage] = useState(null);
  const [data, setData] = useState(null);

  useEffect(() => {
    getChatlist(user?.token).then(res => {
      setData(res.data?.data);
    })
      .catch(err => {
        toast.error(err.messages);
      })
  }, [user?.token]);

  useEffect(() => {
    if (chatingUser) {
      if (
        data &&
        data?.list.users?.some((it) =>
          it.userId.includes(chatingUser._id)
        )
      ) {
        const payload = {
          senderId: chatingUser._id,
          recieverId: user?.user._id,
        };
        getChatMessages(payload, user.token).then((res) => {
          setMessages(res.data.data);
          setSelectedChat({ user: chatingUser, userId: chatingUser._id });
        });
      } else {
        setSelectedChat({ user: chatingUser, userId: chatingUser._id });
      }
    }
  }, [chatingUser, data, user._id, user.token, user?.user._id]);

  useEffect(() => {
    socket.current = io("http://localhost:5000");
    socket.current?.on("getMessage", (data) => {
      getChatlist(user?.token).then(res => {
        setData(res.data?.data);
      })
        .catch(err => {
          toast.error(err.messages);
        })
      setArrivalMessage({
        senderId: data.senderId,
        recieverId: data.recieverId,
        text: data.text,
        createdAt: Date.now(),
      });

    });
  }, [selectedChat, user?.token]);


  useEffect(() => {
    arrivalMessage &&
      data?.list?.users?.some((it) =>
        it.userId.includes(arrivalMessage.senderId)
      ) &&
      setMessages((prev) => [...prev, arrivalMessage]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arrivalMessage]);

  useEffect(() => {
    socket.current.emit("addUser", user?.user?._id);
  }, [user._id, user?.user?._id]);


  const sendMessageHandler = async (message) => {
    const recieverId = selectedChat?.userId;
    socket.current.emit("sendMessage", {
      senderId: user?.user._id,
      recieverId,
      text: message,
    });

    try {
      const dataPayload = {
        senderId: user?.user._id,
        recieverId,
        text: message,
        createdAt: Date.now(),
      };
      await sendMessage(dataPayload, user.token);
      getChatlist(user?.token).then(res => {
        setData(res.data?.data);
      })
        .catch(err => {
          toast.error(err.messages);
        })
      setMessages((p) => [...p, dataPayload]);
    } catch (err) {
      toast.error(err.message);
    }
  };


  return (
    <div className="chatList">
      <h6>Messages</h6>
      <SingleChat
        selectedUser={chatingUser}
        messages={messages}
        sendMessageHandler={sendMessageHandler}
      />
    </div>
  );
};

export default ChatList;
