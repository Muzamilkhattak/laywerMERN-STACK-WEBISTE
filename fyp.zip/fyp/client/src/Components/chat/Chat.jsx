import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Form,
  Alert,
  Container,
  Col,
  Spinner
} from "react-bootstrap";
import io from "socket.io-client";
import "./chat.css";
import "react-toastify/dist/ReactToastify.css";
import { FaEdit, FaTrash, FaUser } from "react-icons/fa";
import { toast } from "react-toastify";
import { uploadFile } from "../../APIS";
import Attach from "../../Assets/attach.png";

let socket;

const Chat = () => {
  const [img, setImg] = useState(null);
  const [imgLoading, setImageLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [msg, setMsg] = useState(null);
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [error, setError] = useState("");
  const ref = useRef();
  let currentUser = sessionStorage.getItem("lawyer-user") ? JSON.parse(sessionStorage.getItem("lawyer-user")) : null;
  currentUser = currentUser?.user?.user;
  const username = currentUser?.firstName + " " + currentUser?.lastName;

  useEffect(() => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    socket = io("http://localhost:5000");

    socket.emit("join", { username }, (error) => {
      if (error) {
        setError(error);
      }
    });

    socket.on("message", (newMessage) => {
      console.log("New Message: ", newMessage);
      if (newMessage.delete) {
        setMessages((prevMessages) => prevMessages.filter(it => it._id !== newMessage.deleteId));
      } else if (newMessage.edit) {
        const msgsCopy = [...messages];
        const ind = msgsCopy.findIndex(it => it._id === newMessage._id);
        console.log("Edit : ", msgsCopy, ind);
        if (ind >= 0) {
          msgsCopy[ind].text = newMessage.text;
          msgsCopy[ind].user = newMessage.user;
          msgsCopy[ind].url = newMessage.url;
          msgsCopy[ind].userId = newMessage.userId;
          setMessages(msgsCopy);
        }

      } else {
        setMessages((prevMessages) => [...prevMessages, {
          ...newMessage,
          timestamp: newMessage.timestamp || new Date().toISOString() // Ensure a timestamp is always present
        }]);
      }
    });


    socket.on("userList", (userList) => {
      setUsers(userList);
    });

    return () => {
      socket.disconnect();
    };
  }, [username]);

  const formatChatDate = (date) => {
    const today = new Date();
    today.setHours(0);
    today.setMinutes(0);
    today.setSeconds(0);
    date.setHours(0);
    date.setMinutes(0);
    date.setSeconds(0);
    const diff = ~~((date.getTime() - today.getTime()) / (1000 * 3600 * 24));

    if (diff < -1) {
      // If date is before yesterday, return the date in "day month year" format
      const options = { day: 'numeric', month: 'short', year: '2-digit' };
      return date.toLocaleDateString('en-PK', options);
    } else if (diff < 0) {
      // If date is yesterday, return "Yesterday"
      return 'Yesterday';
    } else if (diff < 1) {
      // If date is today, return "Today"
      return 'Today';
    } else {
      // For future dates after tomorrow, return the date in "day month year" format
      const options = { day: 'numeric', month: 'short', year: '2-digit' };
      return date.toLocaleDateString('en-PK', options);
    }
  };


  function checkFileType(url) {
    let image = false;
    let imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp'];
    let pdfExtensions = ['pdf'];
    for (let j = 0; j < imageExtensions.length; j++) {
      if (url.includes(imageExtensions[j])) {
        image = true;
      }
    }
    return {
      image,
      pdf: url.includes(pdfExtensions)
    }
  }


  function fileClickedHandler(url) {
    window.open(url, "_blank")
  }

  const sendMessage = (e) => {
    e.preventDefault();
    if (msg) {
      const messageWithTimestamp = {
        id: msg ? msg._id : "",
        user: username,
        userId: currentUser?._id,
        text: message,
        url: img,
        timestamp: new Date().toISOString() // Add ISO string timestamp
      };

      if (message.trim() !== "") {
        socket.emit("editMessage", messageWithTimestamp, (error) => {
          if (error) {
            console.log(error);
            setError(error);
          }
        });
        setMessage("");
        setImg("");
        setMsg(null);
      }
    } else {

      const messageWithTimestamp = {
        user: username,
        userId: currentUser?._id,
        text: message,
        url: img,
        timestamp: new Date().toISOString() // Add ISO string timestamp
      };

      if (message.trim() !== "") {
        socket.emit("sendMessage", messageWithTimestamp, (error) => {
          if (error) {
            console.log(error);
            setError(error);
          }
        });
        setMessage("");
        setImg("");
        setMsg(null);
      }
    }
  };
  const deleteMessage = (id) => {
    const payload = {
      id
    }
    socket.emit("deleteMessage", payload, (error) => {
      if (error) {
        console.log(error);
        setError(error);
      }
    });
  };

  useEffect(() => {
    socket.on("previousMessages", (messages) => {
      setMessages(messages.reverse()); // Assuming messages are ordered newest first from the server
    });

    // Cleanup on unmount
    return () => socket.off("previousMessages");
  }, []);
  // Helper function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    };
    return date.toLocaleTimeString([], options);
  };


  const uploadImageHandler = async (file) => {
    try {
      setImageLoading(true);
      const ext = file.name.split('.').pop();
      const url = await uploadFile(file, "." + ext);
      setImg(url);
      setImageLoading(false);
      toast.success("File uploaded!");
    } catch (error) {
      setImageLoading(false);
      console.log(error);
    }
  }

  const transformMessages = useMemo(() => {
    const groupedData = {};
    messages.forEach((item) => {
      const date = new Date(item.timestamp).toISOString().split('T')[0];
      if (!groupedData[date]) {
        groupedData[date] = [];
      }
      groupedData[date].push(item);
    });
    return Object.entries(groupedData).map(([date, items]) => ({
      date,
      items
    }));

  }, [messages]);
  const transformUsers = useMemo(() => {
    return allUsers.sort((obj1, obj2) => {
      if (users.includes(obj1?.firstName + " " + obj1?.lastName) && !(users.includes(obj2?.firstName + " " + obj2?.lastName))) {
        return -1;
      }
      if (!(users.includes(obj1?.firstName + " " + obj1?.lastName)) && (users.includes(obj2?.firstName + " " + obj2?.lastName))) {
        return 1;
      }
      return 0;
    });

  }, [allUsers, users]);


  return (
    <div className="chat-home">
      <div className="chat-container">
        <div className="sidebar-chat">
          <div className="navbar">
            <span className="logo" style={{ textAlign: "center", width: "100%" }}>Chats</span>
            <div className="user">
              {currentUser?.image ? (
                <img
                  src={currentUser?.image}
                  alt={currentUser?.firstName || "User"}
                />
              ) : (
                <FaUser size={24} /> // You can adjust the size as needed
              )}
              <span>{currentUser?.firstName}</span>
            </div>
          </div>
          {currentUser && (
            <div className="chats">
              {transformUsers?.map((usr, index) => {
                return (
                  <>
                    {currentUser?._id !== usr._id && (
                      <div
                        key={usr._id}
                        className="userChat"
                      >
                        <div style={{ position: "relative" }}>
                          <img src={usr?.image ? usr?.image : "placeholder.png"} alt="" />
                          {
                            users.includes(usr?.firstName + " " + usr?.lastName) ? (
                              <span className="online-tick"></span>
                            ) : ""
                          }
                        </div>
                        <div className="userChatInfo">
                          <span>{usr?.firstName + " " + usr?.lastName}</span>
                        </div>
                      </div>
                    )}
                  </>
                );
              })}
            </div>
          )}
        </div>
        <div className="messages-container" >
          <div className="chat">
            <div className="messages">
              {
                transformMessages.map((dateMessages) => {
                  return <div>
                    <h6 className="message-date">{formatChatDate(new Date(dateMessages.date))}</h6>
                    {dateMessages.items.map((it) => (
                      <>
                        <div ref={ref} className={it.userId?._id.includes(currentUser?._id) ? "message owner" : "message"}>
                          <div className="messageInfo">
                            <div style={{ position: "relative" }}>
                              <img src={it.userId?.image ? it.userId?.image : "placeholder.png"} alt="" />
                              <div>
                                <h6>{it.user}</h6>
                                {it.userId && (<span>({it.userId?.userType})</span>)}
                              </div>
                            </div>
                          </div>
                          <div className="messageContent">
                            <div className="message-options">
                              <>
                                <FaEdit fill="#fff" fontSize={12} onClick={() => {
                                  setMsg(it);
                                  setImg(it.url);
                                  setMessage(it.text);
                                }} />
                              </>
                              <>
                                <FaTrash fill="#fff" fontSize={12} onClick={() => deleteMessage(it._id)} />
                              </>
                            </div>
                            <p>
                              {(it.url && it.url.length) ? (
                                checkFileType(it.url).image && (
                                  <img onClick={() => fileClickedHandler(it.url)} style={{ borderRadius: "5px" }} src={it.url} alt="" width={50} height={50} />
                                )
                              ) : ""}
                              {it.text}
                              <div className="message-time">{formatDate(it.timestamp)}</div>
                            </p>
                          </div>
                        </div>
                      </>
                    ))}
                  </div>
                })
              }
            </div>
          </div>
        </div>
        <div className="chat">
          <div className="messages">
            {error && <Alert variant="danger">{error}</Alert>}
            <Container style={{ height: "100%" }}>

              <Col sm={12}>
                <Form onSubmit={sendMessage}>
                  <div
                    className="input"
                    style={{ border: "1px solid #000", borderRadius: "10px" }}
                  >
                    <input
                      type="text"
                      placeholder="Type something..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                    />
                    <div className="send">
                      <input
                        type="file"
                        style={{ display: "none" }}
                        accept=".jpg, .jpeg, .png, .pdf"
                        id="file"
                        onChange={(e) => uploadImageHandler(e.target.files[0])}
                      />
                      {
                        imgLoading ? (
                          <Spinner animation="grow" variant="dark" />
                        ) : (
                          <label htmlFor="file">
                            <img src={Attach} alt="" />
                          </label>
                        )
                      }
                      <button
                        type="submit"
                        className="send-button"
                        style={{ borderRadius: "10px", padding: "7px 15px" }}
                      >
                        Send
                      </button>
                    </div>
                  </div>
                </Form>
              </Col>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
