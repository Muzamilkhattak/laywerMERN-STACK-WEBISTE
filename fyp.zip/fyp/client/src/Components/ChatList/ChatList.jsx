import "./ChatList.css";
import { SERVER_URL1 } from "../../APIS";


const ChatList = ({ users, selectUserHandler }) => {
  return (
    <>
      <div className="chatList mt-5">
        <div className="chatListCards">
          {users.map((item) => (
            <div
              className="chatListCard"
              onClick={() => selectUserHandler(item)}
            >
              <div className="chatListCardImg">
                <img
                  src={
                    item.user?.image
                      ? SERVER_URL1 + item.user?.image
                      : "/placeholder.png"
                  }
                  alt=""
                />
              </div>
              <div className="chatListCardContent">
                <h6>{item.user?.name}</h6>
                <p>{item.lastMessage}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default ChatList;
