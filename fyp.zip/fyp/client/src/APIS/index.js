import axios from "axios";
export const SERVER_URL = "http://localhost:5000/api";
export const SERVER_URL1 = "http://localhost:5000/";

export const uploadFile = async (data) => {
	let config = {
		method: "post",
		url: SERVER_URL + "/image/upload",
		headers: {
			"Content-Type": "multipart/form-data",
		},
		data: data,
	};
	return await axios.request(config);
};
export const loginAdmin = async (data) => {
	let config = {
		method: "post",
		url: SERVER_URL + "/admin/login",
		headers: {
			"Content-Type": "application/json",
		},
		data: JSON.stringify(data),
	};
	return await axios.request(config);
};
export const approveLawyer = async (data) => {
	let config = {
		method: "post",
		url: SERVER_URL + "/lawyer/status/" + data.id,
		headers: {
			"Content-Type": "application/json",
		},
		data: JSON.stringify(data),
	};
	return await axios.request(config);
};
export const getLawyers = async (page, limit) => {
	let config = {
		method: "get",
		url: SERVER_URL + `/lawyer?page=${page}&limit=${limit}`,
		headers: {
			"Content-Type": "application/json",
		},
	};
	return await axios.request(config);
};
export const getAllLawyers = async () => {
	let config = {
		method: "get",
		url: SERVER_URL + `/lawyer?page=${1}&limit=${100}`,
		headers: {
			"Content-Type": "application/json",
		},
	};
	return await axios.request(config);
};

export const getChatlist = async (token) => {
	const payload = {
		method: "get",
		url: SERVER_URL + "/chat/chatlist",
		headers: {
			"content-type": "application/json",
			"x-auth-token": token,
		},
	};
	return await axios(payload);
};

export const addToChatListHandler = async (token, data) => {
	const payload = {
		method: "post",
		url: SERVER_URL + "/chat/chatlist/add",
		headers: {
			"content-type": "application/json",
			"x-auth-token": token,
		},
		data: JSON.stringify(data),
	};
	return await axios(payload);
};
export const getChatMessages = async (data, token) => {
	const payload = {
		method: "post",
		url: SERVER_URL + "/chat/get",
		headers: {
			"content-type": "application/json",
			"x-auth-token": token,
		},
		data: JSON.stringify(data),
	};
	return await axios(payload);
};
export const sendMessage = async (data, token) => {
	const payload = {
		method: "post",
		url: SERVER_URL + "/chat/add",
		headers: {
			"content-type": "application/json",
			"x-auth-token": token,
		},
		data: JSON.stringify(data),
	};
	return await axios(payload);
};
export const changeMessageStatus = async (data, token) => {
	const payload = {
		method: "post",
		url: SERVER_URL + "/chat/status",
		headers: {
			"content-type": "application/json",
			"x-auth-token": token,
		},
		data: JSON.stringify(data),
	};
	return await axios(payload);
};