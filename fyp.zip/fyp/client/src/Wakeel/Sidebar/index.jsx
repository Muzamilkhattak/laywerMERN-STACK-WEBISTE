import { useState } from "react";
import { Link } from "react-router-dom";
import { FaUser } from "react-icons/fa";
import { CiChat1 } from "react-icons/ci";
import { FiLogOut } from "react-icons/fi";
import "./style.css";

export const WakeelSidebar = ({ children }) => {
  const [activeTab, setActiveTab] = useState("profile");
  const isAuth = sessionStorage.getItem("lawyer-wakeel");

  const logoutHandler = () => {
    const c = window.confirm("Are you sure to logout?");
    if (c) {
      sessionStorage.removeItem("lawyer-wakeel");
      window.location.replace("/wakeel");
    }
  };

  return (
    <div className={`sidebar-container`}>
      {isAuth && (
        <aside className="sidebar-wrapper">
          <div className="sidebar-brand">
            <h4 className="mt-4">Wakeel Pannel</h4>
          </div>
          <ul className="sidebar-nav">
            <li
              className={
                activeTab.includes("profile") ? "active" : ""}
              onClick={() => setActiveTab("/wakeel/profile")}
            >
              <Link to="/wakeel/profile">
                <FaUser />
                <span>Profile</span>
              </Link>
            </li>

            <li
              className={
                activeTab.includes("chat") ? "active" : ""}
              onClick={() => setActiveTab("/wakeel/chat")}
            >
              <Link to="/wakeel/chat">
                <CiChat1 />
                <span>Chat</span>
              </Link>
            </li>
            <li
              className={activeTab.includes("logout") ? "active" : ""}
              onClick={logoutHandler}
            >
              <a href="#logout">
                <FiLogOut />
                <span>Logout</span>
              </a>
            </li>
          </ul>
        </aside>
      )}
      <section className="content-wrapper">{children}</section>
    </div>

  );
};
