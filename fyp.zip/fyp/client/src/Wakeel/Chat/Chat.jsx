import { useState, useCallback, useEffect, useRef } from "react";
import { getChatMessages, sendMessage } from "../../APIS";
import ChatList from "../../Components/ChatList/ChatList";
import SingleChat from "./SingleChat/SingleChat";
import { toast } from "react-toastify";
import { io } from "socket.io-client";
import "./Chat.css";
import { FiArrowRight } from "react-icons/fi";


const Chat = ({ messages: chats, refreshChat, user: chatUser }) => {
  let userWakeel = sessionStorage.getItem("lawyer-wakeel") ? JSON.parse(sessionStorage.getItem("lawyer-wakeel")) : null;
  const [messages, setMessages] = useState([]);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [user, setUser] = useState(null);
  const [arrivalMessage, setArrivalMessage] = useState(null);
  const socket = useRef();

  const selectUserHandler = useCallback(
    async (user) => {
      try {
        const data = {
          senderId: user.userId,
          recieverId: userWakeel?.user._id,
        };
        const res = await getChatMessages(data, userWakeel.token);
        console.log(user, res);
        if (res.status === 200) {
          setMessages(res.data.data);
          setUser(user);
        }
      } catch (err) {
        toast.error(err.message);
      }
    },
    [userWakeel.token, userWakeel?.user._id]
  );

  useEffect(() => {
    if (chatUser) {
      selectUserHandler({ ...chatUser, userId: chatUser._id });
    }
  }, [chatUser, selectUserHandler]);

  useEffect(() => {
    socket.current = io("http://localhost:5000");
    socket.current?.on("getMessage", (data) => {
      refreshChat();
      setArrivalMessage({
        senderId: data.senderId,
        recieverId: data.recieverId,
        text: data.text,
        createdAt: Date.now(),
      });
      console.log("Lawyer portal (New msg data) : ", data);
    });
  }, [refreshChat]);

  useEffect(() => {
    arrivalMessage &&
      chats?.some((it) => it.userId.includes(arrivalMessage.senderId)) &&
      setMessages((prev) => [...prev, arrivalMessage]);
    console.log("Lawyer portal (New mssg) : ", arrivalMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arrivalMessage]);

  useEffect(() => {
    socket.current.emit("addUser", userWakeel?.user._id);
    socket.current.on("getUsers", (users) => {
      setOnlineUsers(
        chats.filter((f) => chats.some((u) => u.userId === f))
      );
    });
  }, [chats, userWakeel?.user._id]);

  const sendMessageHandler = async (message) => {
    const recieverId = user.userId;
    socket.current.emit("sendMessage", {
      senderId: userWakeel._id,
      recieverId,
      text: message,
    });

    try {
      const data = {
        senderId: userWakeel?.user._id,
        recieverId: user.userId,
        text: message,
        createdAt: Date.now(),
      };
      await sendMessage(data, userWakeel.token);
      refreshChat();
      setMessages((p) => [...p, data]);
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="dashboardMain">
      <h6 className="mt-4 mx-5">Messages</h6>
      <div className="chatScreenMain">
        {user && (
          <div className="messageToggle" onClick={() => setUser(null)}>
            <FiArrowRight />
          </div>
        )}
        {chats.length ? (
          <div className="row">
            <div className={`col-md-5 chatList ${user ? "hide" : ""}`}>
              <ChatList users={chats} selectUserHandler={selectUserHandler} />
            </div>
            <div className={` col-md-7 ${!user ? "hideChat" : ""}`}>
              {user ? (
                <div className="singleChat">
                  <SingleChat
                    selectedUser={user}
                    messages={messages}
                    sendMessageHandler={sendMessageHandler}
                  />
                </div>
              ) : (
                <div className="select-chat-container">
                  <img src="/selectChat.png" alt="select-chat" />
                  <h4>Select chat</h4>
                  <p>Select a conversation and chat away</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="select-chat-container">
            <img src="/selectChat.png" alt="select-chat" />
            <p>You haven't chated with anyone yet!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;
