import { useEffect, useMemo, useState } from "react";
import { getChatlist } from "../../APIS";
import Chat from "../Chat/Chat";
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";

export const Messages = () => {
  let userWakeel = sessionStorage.getItem("lawyer-wakeel") ? JSON.parse(sessionStorage.getItem("lawyer-wakeel")) : null;
  const { state } = useLocation();
  const [data, setData] = useState(null);

  useEffect(() => {
    getChatlist(userWakeel?.token).then(res => {
      setData(res.data?.data);
    })
      .catch(err => {
        toast.error(err.messages);
      })
  }, [userWakeel?.token]);

  const transformList = useMemo(() => {
    const messages = data?.list ? data?.list.users : [];
    const users = data?.users;
    return messages?.map((it) => ({
      ...it,
      user: users.find((usr) => usr._id.includes(it.userId)),
    }));
  }, [data?.list, data?.users]);

  return (
    <Chat
      messages={transformList ? transformList : []}
      refreshChat={() => {
        getChatlist(userWakeel?.token).then(res => {
          setData(res.data?.data);
        })
          .catch(err => {
            toast.error(err.messages);
          })
      }}
      user={state?.user ? state.user : null}
    />
  );
};
