import React, { useState } from 'react'
import './Wakeelr.css';
import logo from '../../Assets/Img/wakeelr.png'
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { uploadFile } from '../../APIS';

function Wakeelr() {


   const [data, setData] = useState({
      name: "",
      password: "",
      phoneNumber: "",
      city: "",
      state: "",
      email: "",
      experience: "",
      experienceInYears: "",
      cnic: "",
      qualifications: "",
      areaOfExpertise: "",
      skypeId: "",
      profileImageUrl: "",
      resumeUrl: ""
   })

   const handleInput = (e) => {
      setData({ ...data, [e.target.name]: e.target.value })
   }

   const handleImageUpload = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
         const formData = new FormData();
         formData.append("file", file);
         const res = await uploadFile(formData);
         setData(p => ({
            ...p,
            [e.target.name]: res.data.data,
         }))
      } catch (error) {
         alert(error.message);
      }
   };

   function handleSubmitData(event) {
      event.preventDefault();
      axios.post('http://localhost:5000/api/lawyer/register', { ...data })
         .then((res) => {
            sessionStorage.setItem("lawyer-wakeel", JSON.stringify(res.data));
            alert("Register success!");
            window.location.replace("/wakeel");
         })
         .catch((err) => {
            console.error('Error with Axios:', err);
         });
   };

   return (
      <>
         <div className="wakeelrmain ">

            <div className="wakeelrleft">
               <img src={logo} alt="" />
            </div>

            <div className="wakeelrright">

               <form className="wakelrform" onSubmit={handleSubmitData} method='post' >

                  <div className='layerr'>LAWYER REGISTRATION</div>

                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">Name</label><br />
                        <input type="text" placeholder='Enter name' name='name' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">Email Address</label><br />
                        <input type="email" placeholder='Enter Email' name='email' onChange={handleInput} /><br />
                     </div>
                  </div>

                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">CNIC NO.</label><br />
                        <input type="text" placeholder='Enter CNIC Number' name='cnic' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">Phone Number</label><br />
                        <input type="text" placeholder='03249518191' name='phoneNumber' onChange={handleInput} /><br />
                     </div>
                  </div>


                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">State</label><br />
                        <input type="text" placeholder='Enter State' name='state' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">City</label><br />
                        <input type="text" placeholder='Enter City' name='city' onChange={handleInput} /><br />
                     </div>
                  </div>


                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">Password</label><br />
                        <input type="text" placeholder='Enter Passward' name='password' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">Experience</label><br />
                        <input type="text" placeholder='Enter your Experience' name='experience' onChange={handleInput} /><br />
                     </div>
                  </div>

                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">Experience in years</label><br />
                        <input type="text" placeholder='4 Years' name='experienceInYears' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">Qualifications</label><br />
                        <input type="text" placeholder='Qualifications'
                           name='qualifications' onChange={handleInput} /><br />
                     </div>
                  </div>


                  <div className='fordis2'>
                     <div>
                        <label htmlFor="">Area of Expertise</label><br />
                        <input type="text" placeholder='Area of Expertise' name='areaofExpertise' onChange={handleInput} /><br />
                     </div>

                     <div>
                        <label htmlFor="">Skype Id</label><br />
                        <input type="text" placeholder='Enter Skype Id' name='skypeId' onChange={handleInput} /><br />
                     </div>
                  </div>

                  <div className='fordis2file'>
                     <div>
                        <label htmlFor="">Profile Picture</label><br />
                        <input type="file" accept='image/*' name='profileImageUrl' onChange={handleImageUpload} /><br />
                     </div>
                     <div>
                        <label htmlFor="">Resume</label><br />
                        <input type="file" accept='image/*' name='resumeUrl' onChange={handleImageUpload} /><br />
                     </div>
                  </div>

                  <div className='privacypolicy paddpr'><input type="checkbox" name="" id="" /> I agree to Apnawakeel.pk Privacy Policy & Terms.</div>

                  <div className='button'><button type="submit">Create Account</button></div>
                  <div className='already paddal'> Already have an account? <span><NavLink to='/wakeel'>Login</NavLink></span></div>


               </form>

            </div>

         </div>
      </>
   )
}

export default Wakeelr;