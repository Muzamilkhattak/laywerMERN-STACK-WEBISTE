import React, { useState } from 'react'
import axios from 'axios';
import { uploadFile } from '../../APIS';

export const WakeelProfile = () => {
	let user = sessionStorage.getItem("lawyer-wakeel") ? JSON.parse(sessionStorage.getItem("lawyer-wakeel")) : null;

	const [data, setData] = useState({
		name: user ? user.user.name : "",
		phoneNumber: user ? user.user.phoneNumber : "",
		city: user ? user.user.city : "",
		state: user ? user.user.state : "",
		email: user ? user.user.email : "",
		experience: user ? user.user.experience : "",
		experienceInYears: user ? user.user.experienceInYears : "",
		cnic: user ? user.user.cnic : "",
		qualifications: user ? user.user.qualifications : "",
		areaOfExpertise: user ? user.user.areaOfExpertise : "",
		skypeId: user ? user.user.skypeId : "",
		profileImageUrl: user ? user.user.profileImageUrl : "",
		resumeUrl: user ? user.user.resumeUrl : ""
	})

	const handleInput = (e) => {
		setData({ ...data, [e.target.name]: e.target.value })
	}

	const handleImageUpload = async (e) => {
		const file = e.target.files[0];
		if (!file) return;
		try {
			const formData = new FormData();
			formData.append("file", file);
			const res = await uploadFile(formData);
			setData(p => ({
				...p,
				[e.target.name]: res.data.data,
			}))
		} catch (error) {
			alert(error.message);
		}
	};

	function handleSubmitData(event) {
		event.preventDefault();
		console.log('Submitting data...');
		axios.post('http://localhost:5000/api/lawyer/update/' + user?.user?._id, { ...data })
			.then((res) => {
				sessionStorage.setItem("lawyer-wakeel", JSON.stringify({ token: user?.token, user: res.data.data }));
				alert("Update success!");
				window.location.replace("/wakeel");
			})
			.catch((err) => {
				console.error('Error with Axios:', err);
			});
	};




	return (
		<div className="wakeelrright">

			<form className="wakelrform" onSubmit={handleSubmitData} method='post' >

				<div className='layerr'>LAWYER Profile</div>

				<div className='fordis2'>
					<div>
						<label htmlFor="">Name</label><br />
						<input type="text" value={data.name} placeholder='Enter name' name='name' onChange={handleInput} /><br />
					</div>

					<div>
						<label htmlFor="">Email Address</label><br />
						<input disabled type="email" value={data.email} placeholder='Enter Email' name='email' onChange={handleInput} /><br />
					</div>
				</div>

				<div className='fordis2'>
					<div>
						<label htmlFor="">CNIC NO.</label><br />
						<input type="text" value={data.cnic} placeholder='Enter CNIC Number' name='cnic' onChange={handleInput} /><br />
					</div>

					<div>
						<label htmlFor="">Phone Number</label><br />
						<input type="text" value={data.phoneNumber} placeholder='03249518191' name='phoneNumber' onChange={handleInput} /><br />
					</div>
				</div>


				<div className='fordis2'>
					<div>
						<label htmlFor="">State</label><br />
						<input type="text" value={data.state} placeholder='Enter State' name='state' onChange={handleInput} /><br />
					</div>

					<div>
						<label htmlFor="">City</label><br />
						<input type="text" value={data.city} placeholder='Enter City' name='city' onChange={handleInput} /><br />
					</div>
				</div>


				<div className='fordis2'>

					<div>
						<label htmlFor="">Experience</label><br />
						<input type="text" value={data.experience} placeholder='Enter your Experience' name='experience' onChange={handleInput} /><br />
					</div>
				</div>

				<div className='fordis2'>
					<div>
						<label htmlFor="">Experience in years</label><br />
						<input type="text" value={data.experienceInYears} placeholder='4 Years' name='experienceInYears' onChange={handleInput} /><br />
					</div>

					<div>
						<label htmlFor="">Qualifications</label><br />
						<input type="text" placeholder='Qualifications'
							value={data.qualifications} name='qualifications' onChange={handleInput} /><br />
					</div>
				</div>


				<div className='fordis2'>
					<div>
						<label htmlFor="">Area of Expertise</label><br />
						<input value={data.areaOfExpertise} type="text" placeholder='Area of Expertise' name='areaOfExpertise' onChange={handleInput} /><br />
					</div>

					<div>
						<label htmlFor="">Skype Id</label><br />
						<input value={data.skypeId} type="text" placeholder='Enter Skype Id' name='skypeId' onChange={handleInput} /><br />
					</div>
				</div>

				<div className='fordis2file mt-2'>
					<div>
						<img src={`http://localhost:5000/${data.profileImageUrl}`} width="100%" alt='' height={200} />
						<label htmlFor="">Profile Picture</label><br />
						<input type="file" accept='image/*' name='profileImageUrl' onChange={handleImageUpload} /><br />
					</div>
					<div>
						<img src={`http://localhost:5000/${data.resumeUrl}`} alt='' width="100%" height={200} />
						<label htmlFor="">Resume</label><br />
						<input type="file" accept='image/*' name='resumeUrl' onChange={handleImageUpload} /><br />
					</div>
				</div>

				<div className='button my-3'><button type="submit">Update Account</button></div>

			</form>

		</div>
	)
}